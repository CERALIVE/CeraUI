# @ceralive/cerastream (TypeScript bindings)

Type-safe control-IPC **schema + client surface** for the cerastream Rust
streaming engine. This package is the **public contract** (ADR-0002 Decision 13):
a CI-published npm package — **not** a sibling `link:` dep — consumable by Bun with
zero native dependencies.

- JSON-RPC 2.0 envelope + `hello` handshake schemas
- The eight v1 control methods (params + result Zod schemas + inferred types)
- The seven server-push event payloads (discriminated union)
- Two-tier error codes (Tier 1 RPC + Tier 2 runtime, 1:1 with CeraUI)
- A unified engine config schema (= `start` params)
- A `CerastreamClient` interface + `connect()` factory

> **v0.1.0-stub — contract-first.** The Zod schemas, types, and constants are
> real and **frozen**. Every *function* (`connect` + path/exec helpers) throws
> `NotImplementedError` until the transport implementation lands (plan Task 31).
> Wave-3 Rust tasks consume the **schema**, not behavior.

See [`API.md`](./API.md) for the full exported surface, ADR-0002
([`../../docs/adr/ADR-0002-control-ipc.md`](../../docs/adr/ADR-0002-control-ipc.md))
for the protocol decision, and `schema.md`
([`../../docs/adr/schema.md`](../../docs/adr/schema.md)) for the v1 message
inventory.

## Install / develop

```bash
bun install
bun run typecheck   # tsc --noEmit
bun test            # schema round-trip + stub-honesty + count + skew guards
bun run build       # emit dist/
```

## Usage (schema today, client after Task 31)

The schemas are usable now — validate any control message on either side of the
wire:

```ts
import { startParamsSchema, eventParamsSchema } from "@ceralive/cerastream";

const params = startParamsSchema.parse({
  pipeline: "h264_camlink_1080p",
  srt: { host: "relay.example.com", port: 8890, latency_ms: 2000 },
  bitrate: { min_bitrate: 500, max_bitrate: 6000 }, // balancer defaults to "adaptive"
});

const event = eventParamsSchema.parse(incomingNotification.params); // typed by `type`
```

The client factory is a stub until Task 31:

```ts
import { connect } from "@ceralive/cerastream";

await connect({}); // throws NotImplementedError (by design, v0.1.0-stub)
```

## Versioning

npm semver tracks the schema (ADR-0002 §4). Within protocol major
`cerastream-ipc/1` the surface is **additive-only**. The exported surface is
frozen as of this stub; new surface is added additively. See
[`CHANGELOG.md`](./CHANGELOG.md).
