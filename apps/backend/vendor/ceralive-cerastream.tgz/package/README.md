# @ceralive/cerastream

Type-safe control-IPC **schema + client** for the cerastream streaming engine.
A zero-native-dependency package — the published contract for driving the
engine's JSON-RPC 2.0 / NDJSON control plane over a Unix domain socket.

- JSON-RPC 2.0 envelope + `hello` handshake schemas
- The eight v1 control methods (Zod params + result schemas + inferred types)
- The seven server-push event payloads (discriminated union)
- Two-tier error codes (RPC + runtime)
- A unified engine config schema (= `start` params)
- A `CerastreamClient` interface + `connect()` factory (UDS transport)

The Zod schemas, types, and constants are the frozen wire contract; `connect()`
drives that contract over an NDJSON/UDS transport with no native dependencies.

## Install

```bash
npm i @ceralive/cerastream
# or
bun add @ceralive/cerastream
```

## Usage

The schemas validate any control message on either side of the wire:

```ts
import { startParamsSchema, eventParamsSchema } from "@ceralive/cerastream";

const params = startParamsSchema.parse({
  pipeline: "h264_camlink_1080p",
  srt: { host: "relay.example.com", port: 8890, latency_ms: 2000 },
  bitrate: { min_bitrate: 500, max_bitrate: 6000 }, // balancer defaults to "adaptive"
});

const event = eventParamsSchema.parse(incomingNotification.params); // typed by `type`
```

Drive the engine through the control plane:

```ts
import { connect } from "@ceralive/cerastream";

const client = await connect({ autoReconnect: true }); // hello handshake runs here
console.log(client.hello.engine_version);

const sub = await client.subscribeEvents({ topics: ["status", "bitrate"] }, (ev) => {
  if (ev.type === "bitrate") console.log("bitrate", ev.current_bitrate);
});

await client.start({
  pipeline: "h264_camlink_1080p",
  srt: { host: "relay.example.com", port: 8890, latency_ms: 2000 },
  bitrate: { min_bitrate: 500, max_bitrate: 6000 },
});
await client.setBitrate({ max_bitrate: 4500 });
await client.switchInput({ input_id: "video0" });
await client.stop();

sub.close();
await client.close(); // closes the connection; never spawns the engine
```

`connect()` honours `socketPath`, `requestTimeoutMs`, and `autoReconnect`
(capped backoff + re-handshake + re-subscribe). The engine runs as a
systemd-owned service — the client connects to it and never spawns it.

## Versioning

Two independent version axes. The **wire-schema version** (`PROTOCOL_VERSION` +
`SCHEMA_VERSION`) is pinned cross-language with the engine and is additive-only
within `cerastream-ipc/1`. The **npm package version** is CalVer
(`YYYY.MINOR.PATCH`) with SemVer intent applied to the exported TypeScript
surface; release candidates use `-rc.N` (npm `next` dist-tag).

## License

GPL-3.0
